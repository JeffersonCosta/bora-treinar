# Bora Treinar! — Android

Diário pessoal de treino, offline, sem conta ou serviços externos. Aplicação Android Java com WebView local, sem permissão de internet. A interface HTML/CSS/JS está em `app/src/main/assets`.

## Gerar APK no Android Studio

1. Extraia o ZIP e abra a pasta `bora-treinar` no Android Studio.
2. Use JDK 17 e instale Android SDK Platform 35 e Build Tools 35.0.0 no SDK Manager.
3. Sincronize com Gradle. A versão de Gradle compatível é 8.9; este projeto não inclui os binários do wrapper. Se necessário, instale Gradle 8.9 e gere o wrapper com `gradle wrapper --gradle-version 8.9`.
4. No Android Studio, use Build > Generate App Bundles or APKs > Generate APKs (o nome pode variar por versão), ou rode `gradle assembleDebug` com SDK configurado.
5. O APK estará em `app/build/outputs/apk/debug/app-debug.apk`. Transfira para o celular e instale, permitindo instalação dessa origem quando solicitado. Android mínimo 8.0.

Alternativa: suba o conteúdo da pasta em um repositório GitHub e execute o workflow **Gerar APK Android** na aba Actions. Baixe o artefato `Bora-Treinar-APK`. O workflow usa APK debug; para atualizações permanentes, mantenha a mesma chave de assinatura. Uma chave diferente pode exigir desinstalação, apagando os dados — exporte backup antes.

## Uso

- A tela inicial é o calendário mensal. Escolha qualquer dia e qualquer treino da ficha. A sugestão é o primeiro treino ainda não concluído na semana (segunda a domingo).
- Uma sessão por data. A ordem dos treinos é flexível. Se trocar um treino que já possui dados, confirme a substituição.
- Registre cargas em kg (vírgula ou ponto decimal), repetições e marque séries. O botão do exercício marca todas as séries de uma vez. A conclusão do dia é automática quando todos os exercícios estão marcados.
- Cargas das séries feitas anteriormente são sugeridas no próximo treino do mesmo exercício. As repetições ficam em branco para não confundir planejado com executado. Campos podem ficar vazios, por exemplo para exercícios sem carga externa.
- Para halteres, use sempre o mesmo critério (ex.: peso por halter). Para barras, use sempre o mesmo critério (ex.: peso total).
- Em Evolução, consulte as séries feitas e a maior carga registrada por sessão. O gráfico mostra até 12 sessões recentes com carga.
- Minha ficha permite importar, editar e exportar o JSON. O arquivo `meu-treino.json` contém os 26 exercícios iniciais. Os IDs devem ser únicos e estáveis; sessões existentes guardam uma cópia da ficha vigente. O campo `dia` é somente referência e não bloqueia o calendário. As chaves de exercício são `id`, `nome`, `series` (inteiro), `reps` (texto, ex. `8-12`) e `falha` (booleano).
- Exporte backup completo com frequência. Desinstalar o app ou limpar seus dados pode apagar o histórico. Restaurar backup substitui os dados atuais mediante confirmação.

## Testes e limites

`node tests/core.test.cjs` executa testes de lógica e renderização HTML com DOM simulado, sem dependências externas. `node --check app/src/main/assets/app.js` verifica sintaxe JS. O ambiente de criação não possuía Gradle/SDK Android nem acesso de rede para obtê-los. A navegação em navegador automatizado também estava bloqueada por política. Portanto, a compilação Android, o visual real e a integração nativa de seleção de arquivos precisam ser validados em dispositivo ou emulador. Nenhum APK foi gerado neste ambiente.

Para testar a interface sem Android, abra `app/src/main/assets/index.html` em um navegador com armazenamento local habilitado, ou execute `python -m http.server 8000 --directory app/src/main/assets` e acesse `http://localhost:8000`. Os dados do navegador são separados do app Android; use exportação/importação de backup para transferi-los.
