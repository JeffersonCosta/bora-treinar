package br.com.boratreinar;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int OPEN_JSON = 101, SAVE_JSON = 102;
    private WebView web;
    private ValueCallback<Uri[]> pendingFile;
    private String pendingExport;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xff101614);
        setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.getSettings().setBlockNetworkLoads(true);
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !r.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFile != null) pendingFile.onReceiveValue(null);
                pendingFile = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
                try { startActivityForResult(i, OPEN_JSON); }
                catch (Exception e) { pendingFile.onReceiveValue(null); pendingFile = null; toast("Não foi possível abrir arquivos."); }
                return true;
            }
        });
        if (state != null) pendingExport = state.getString("pendingExport");
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); out.putString("pendingExport", pendingExport); }
    private void toast(String msg) { Toast.makeText(this,msg,Toast.LENGTH_SHORT).show(); }
    private class Bridge {
        @JavascriptInterface public void exportJson(String filename, String content) {
            runOnUiThread(() -> {
                if (pendingExport != null) { toast("Já existe uma exportação em andamento."); return; }
                pendingExport = content;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE,filename);
                try { startActivityForResult(i,SAVE_JSON); }
                catch (Exception e) { pendingExport=null; toast("Não foi possível exportar."); }
            });
        }
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request,result,data);
        if (request == OPEN_JSON && pendingFile != null) {
            pendingFile.onReceiveValue(result == RESULT_OK && data != null && data.getData() != null ? new Uri[]{data.getData()} : null);
            pendingFile = null;
        } else if (request == SAVE_JSON) {
            String content = pendingExport; pendingExport = null;
            if (result == RESULT_OK && data != null && data.getData() != null && content != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData(),"wt")) {
                    if (out == null) throw new Exception("Sem destino");
                    out.write(content.getBytes(StandardCharsets.UTF_8)); toast("Arquivo salvo!");
                } catch (Exception e) { toast("Falha ao salvar arquivo."); }
            }
        }
    }
    @Override public void onBackPressed() {
        web.evaluateJavascript("window.onAndroidBack ? window.onAndroidBack() : false", result -> { if (!"true".equals(result)) super.onBackPressed(); });
    }
}
